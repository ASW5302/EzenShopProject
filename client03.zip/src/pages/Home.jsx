import React from "react";

const Home = () => {
  return <div style={{ height: "1000px" }}>Home</div>;
};

export default Home;
