import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Header from "../layout/Header";
import Footer from "../layout/Footer";

const Routes = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default Routes;
