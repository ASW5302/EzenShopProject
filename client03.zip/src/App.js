import React, { useRef } from "react";
import "./index.css";
import styled from "styled-components";
import { BrowserRouter as Router } from "react-router-dom";

import Header from "./layout/Header";
import Footer from "./layout/Footer";

import Home from "./pages/Home";

const App = () => {
  return (
    <div className="h-96">
      <Router>
        <Container>
          <Header />
        </Container>
        <Line />
        <Container>
          <Home />
          <Footer />
        </Container>
      </Router>
    </div>
  );
};

export default App;

const Container = styled.div`
  /* 화면 크기가 640px 이상인 경우 스타일을 변경 */
  @media (min-width: 640px) {
    max-width: 616px;
    margin: 0 auto;
  }

  /* 화면 크기가 768px 이상인 경우 스타일을 변경 */
  @media (min-width: 768px) {
    max-width: 744px;
  }

  /* 화면 크기가 1024px 이상인 경우 스타일을 변경 */
  @media (min-width: 1024px) {
    max-width: 1200px;
  }
`;
const Line = styled.div`
  border-bottom: 1px solid rgba(0, 0, 0, 0.15);
`;
